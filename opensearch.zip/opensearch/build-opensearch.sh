#!/usr/bin/env bash

set -e

docker build --tag opensearch .
